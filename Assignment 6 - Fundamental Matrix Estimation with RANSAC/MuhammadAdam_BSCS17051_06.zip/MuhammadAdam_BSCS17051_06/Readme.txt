There has been no editing done to the main code file so it just runs as it did before.
The editing has been done in the student_code.py file.